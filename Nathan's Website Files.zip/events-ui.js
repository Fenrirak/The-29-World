/* ===================== The 29 World — random event popups =====================
   Weekly random events are assigned to every student once per NZ calendar
   week (see processWeeklyEvents in data.js), but each event gets its own
   random "revealAt" moment spread across the following day or so — so a
   student who was given 3 events doesn't see them (or feel their balance
   change) all at once. This file:
   1. Only surfaces ONE event per check, the earliest one that's come due —
      never a batch — no matter how many are queued up.
   2. For fixed-amount events, doesn't apply the balance change until the
      exact moment it's about to show the popup (via revealFixedEvent in
      data.js) — so a student's balance can never change silently ahead of
      them actually seeing what happened and why.
   3. For multiple-choice events, shows a forced modal that must be
      answered before the student can continue (unchanged from before).
================================================================== */

function eventsShownKey(username) {
  return "anw_events_shown_" + username;
}

function getShownEventState(username) {
  try {
    const raw = localStorage.getItem(eventsShownKey(username));
    return raw ? JSON.parse(raw) : { week: null, ids: [] };
  } catch (e) {
    return { week: null, ids: [] };
  }
}

function saveShownEventState(username, state) {
  try { localStorage.setItem(eventsShownKey(username), JSON.stringify(state)); } catch (e) { /* ignore */ }
}

async function checkWeeklyEventPopup(username, classCode) {
  if (!username || !classCode) return;
  if (anyModalShowing()) return; // something's already showing
  let cls = await getClass(classCode);
  const user = await getUser(username);
  if (!cls || !user) return;
  const weekKey = isoWeekKey(new Date());
  const now = Date.now();
  // revealAt is missing on legacy log entries (from before this field
  // existed) — treat those as already due so nothing old gets stuck.
  const due = (cls.eventLog || []).filter(l => l.studentUser === username && l.week === weekKey && (l.revealAt === undefined || l.revealAt <= now));
  if (due.length === 0) return;

  // Multiple-choice events take priority — forced modal, must be answered.
  const pendingChoice = due.filter(l => l.type === "choice" && l.status === "pending").sort((a, b) => (a.revealAt || 0) - (b.revealAt || 0))[0];
  if (pendingChoice) {
    showChoiceEventPopup(pendingChoice, username, classCode);
    return;
  }

  // Otherwise, find the single earliest-due item the student hasn't seen
  // yet — this includes fixed events still waiting to be revealed
  // ("scheduled") as well as anything already resolved but unshown (a
  // legacy fallback from before "scheduled" existed).
  let state = getShownEventState(username);
  if (state.week !== weekKey) state = { week: weekKey, ids: [] };
  const shown = new Set(state.ids);
  const candidates = due
    .filter(l => l.type === "fixed" && (l.status === "scheduled" || l.status === "resolved") && !shown.has(l.id))
    .sort((a, b) => (a.revealAt || 0) - (b.revealAt || 0));
  if (candidates.length === 0) return;
  let entry = candidates[0];

  if (entry.status === "scheduled") {
    // This is the moment the balance change + txn actually happens — not
    // a moment before. If it's already been revealed by another tab/page
    // load in the meantime, revealFixedEvent just returns the resolved
    // entry instead of double-applying anything.
    const revealed = await revealFixedEvent(classCode, entry.id);
    if (!revealed) return; // someone else's page load already handled it
    entry = revealed;
  }

  const hasGeneralPlan = (user.insurance || [])
    .map(id => cls.insurancePlans.find(p => p.id === id))
    .some(p => p && p.coverage === "general");

  const withDetails = [{
    id: entry.id, name: entry.name || "Random event", description: entry.description || "",
    amount: entry.amount || 0, severity: entry.severity || "neutral", claimed: !!entry.claimed,
    claimable: entry.severity === "bad" && !entry.claimed && hasGeneralPlan
  }];

  showEventPopup(withDetails, username, classCode);

  state.ids = state.ids.concat([entry.id]);
  saveShownEventState(username, state);
}

// Multiple-choice weekly event popup. Has no close button and can't be
// dismissed by clicking outside — the student must pick an option, which
// resolves the event (applies the balance change) via resolveChoiceEvent.
function showChoiceEventPopup(entry, username, classCode) {
  const overlay = document.createElement("div");
  overlay.id = "anwChoiceEventModal";
  overlay.className = "anw-modal-overlay";

  // Amounts are intentionally withheld here — the student should be
  // choosing based on the label/description, not min-maxing the payout.
  // The actual amount + outcome only appears after they've committed.
  const optionsHtml = (entry.options || []).map(o => `
    <button class="btn secondary" style="width:100%;justify-content:flex-start;" data-opt="${o.id}">
      <span>${o.label}</span>
    </button>
  `).join("");

  overlay.innerHTML = `
    <div class="anw-modal-card">
      <h2 style="display:flex;align-items:center;gap:9px;">${icon("dice", 24)} ${entry.name}</h2>
      <p>${entry.description || ""}</p>
      <p class="muted-small">You need to choose how to handle this before you can continue.</p>
      <div style="display:flex;flex-direction:column;gap:10px;margin-top:10px;">
        ${optionsHtml}
      </div>
      <div id="choiceEventMsg"></div>
    </div>
  `;
  document.body.appendChild(overlay);

  overlay.querySelectorAll("[data-opt]").forEach(btn => {
    btn.addEventListener("click", async () => {
      overlay.querySelectorAll("button").forEach(b => b.disabled = true);
      const res = await resolveChoiceEvent(username, classCode, entry.id, btn.getAttribute("data-opt"));
      if (res.ok) {
        showChoiceOutcome(overlay, entry, res.amount, res.outcome, username, classCode);
        if (typeof render === "function") render();
      } else {
        document.getElementById("choiceEventMsg").innerHTML = `<div class="error-msg">${res.error}</div>`;
        overlay.querySelectorAll("button").forEach(b => b.disabled = false);
      }
    });
  });
}

// Swaps the choice modal's content for a reveal of what actually happened
// — this is the first moment the student sees the amount, now that
// they've already committed to their choice.
function showChoiceOutcome(overlay, entry, amount, outcome, username, classCode) {
  const card = overlay.querySelector(".anw-modal-card");
  // Same claimability rule as fixed events: the event def was marked
  // "bad" and the option the student picked actually cost them money.
  // A student who picks a $0/positive option on a "bad" event has
  // nothing to claim, even though the event itself is tagged bad.
  const claimable = entry.severity === "bad" && amount < 0;
  card.innerHTML = `
    <h2 style="display:flex;align-items:center;gap:9px;">${icon("dice", 24)} ${entry.name}</h2>
    ${outcome ? `<p>${outcome}</p>` : ""}
    <p class="${amount < 0 ? 'ticker-down' : 'ticker-up'}" style="font-weight:900;font-size:1.2em;">${amount >= 0 ? "+" : "-"}${fmtMoney(Math.abs(amount))}</p>
    ${claimable ? `<button class="btn small secondary" onclick="claimFromPopup('${entry.id}', '${username}', '${classCode}', this)">${icon("shield", 13)} Claim insurance</button>` : ""}
    <button class="btn gold" style="width:100%;justify-content:center;margin-top:16px;" id="anwChoiceOutcomeCloseBtn">Nice, got it</button>
  `;
  document.getElementById("anwChoiceOutcomeCloseBtn").addEventListener("click", () => overlay.remove());
}

function showEventPopup(events, username, classCode) {
  const existing = document.getElementById("anwEventModal");
  if (existing) existing.remove();

  const overlay = document.createElement("div");
  overlay.id = "anwEventModal";
  overlay.className = "anw-modal-overlay";

  const rows = events.map(e => `
    <div class="anw-event-row">
      <span class="icon" style="width:26px;height:26px;flex-shrink:0;">${icon("dice", 26)}</span>
      <div style="flex:1;">
        <div class="anw-event-name">${e.name}</div>
        ${e.description ? `<div class="muted-small">${e.description}</div>` : ""}
        ${e.claimable ? `<button class="btn small secondary" style="margin-top:6px;" onclick="claimFromPopup('${e.id}', '${username}', '${classCode}', this)">${icon("shield", 13)} Claim insurance</button>` : ""}
        ${e.claimed ? `<div class="muted-small ticker-up">Claimed on insurance</div>` : ""}
      </div>
      <div class="${e.amount < 0 ? 'ticker-down' : 'ticker-up'}" style="font-weight:900;">
        ${e.amount >= 0 ? "+" : "-"}${fmtMoney(Math.abs(e.amount))}
      </div>
    </div>
  `).join("");

  overlay.innerHTML = `
    <div class="anw-modal-card">
      <h2 style="display:flex;align-items:center;gap:9px;">${icon("dice", 24)} Random events this week!</h2>
      <p>Here's what happened to you this week:</p>
      ${rows}
      <button class="btn gold" style="width:100%;justify-content:center;margin-top:16px;" id="anwEventCloseBtn">Nice, got it</button>
    </div>
  `;
  document.body.appendChild(overlay);
  document.getElementById("anwEventCloseBtn").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
}

async function claimFromPopup(eventLogId, username, classCode, btn) {
  btn.disabled = true;
  btn.textContent = "Claiming...";
  const cls = await getClass(classCode);
  const user = await getUser(username);
  const plan = (user.insurance || []).map(id => cls.insurancePlans.find(p => p.id === id)).find(p => p && p.coverage === "general");
  if (!plan) { btn.textContent = "No General plan"; return; }
  const res = await claimInsuranceForEvent(username, classCode, eventLogId, plan.id);
  if (res.ok) {
    btn.outerHTML = `<div class="muted-small ticker-up">Claimed — ${fmtMoney(res.payout)} paid out</div>`;
  } else {
    btn.disabled = false;
    btn.textContent = "Try again";
  }
}

/* ===================== Bonus / fine popup =====================
   When a teacher gives a bonus or fine from the dashboard, the student
   gets a one-time popup (like a good big event) showing the reason and
   the amount, instead of just quietly finding it in their activity feed. */
function anyModalShowing() {
  return !!(document.getElementById("anwEventModal") || document.getElementById("anwChoiceEventModal")
    || document.getElementById("anwBigEventModal") || document.getElementById("anwGoodBigEventModal")
    || document.getElementById("anwAdjustmentModal"));
}

async function checkAdjustmentPopup(username, classCode) {
  if (!username || !classCode) return;
  if (anyModalShowing()) return;
  const cls = await getClass(classCode);
  if (!cls) return;
  const pending = (cls.txns || []).find(t => t.announce && !t.acknowledged && t.to === username && (t.type === "bonus" || t.type === "fine"));
  if (!pending) return;

  showAdjustmentPopup(pending);
  await acknowledgeTxn(classCode, pending.id);
}

function showAdjustmentPopup(txn) {
  const overlay = document.createElement("div");
  overlay.id = "anwAdjustmentModal";
  overlay.className = "anw-modal-overlay";

  const isBonus = txn.type === "bonus";
  overlay.innerHTML = `
    <div class="anw-modal-card">
      <h2 style="display:flex;align-items:center;gap:9px;">${icon(isBonus ? "star" : "coin", 24)} ${isBonus ? "You got a bonus!" : "You got a fine"}</h2>
      ${txn.note ? `<p>${txn.note}</p>` : ""}
      <p class="${isBonus ? 'ticker-up' : 'ticker-down'}" style="font-weight:900;font-size:1.2em;">${isBonus ? "+" : "-"}${fmtMoney(txn.amount)}</p>
      <button class="btn gold" style="width:100%;justify-content:center;margin-top:16px;" id="anwAdjustmentCloseBtn">Nice, got it</button>
    </div>
  `;
  document.body.appendChild(overlay);
  document.getElementById("anwAdjustmentCloseBtn").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
}

/* ===================== Big event popup =====================
   Unlike small weekly events, big events must be resolved — the modal has
   no close button and clicking outside doesn't dismiss it. It reappears on
   every page load until the student picks pay / forfeit / claim. */
const BIG_EVENT_MODULE_LABEL = { income: "Income", property: "Property", transport: "Transport", general: "General" };
const BIG_EVENT_COVERAGE = { income: "jobs", property: "property", transport: "transport" };

function bigEventsShownKey(username) {
  return "anw_bigevents_shown_" + username;
}
function getShownBigEventState(username) {
  try {
    const raw = localStorage.getItem(bigEventsShownKey(username));
    return raw ? JSON.parse(raw) : { ids: [] };
  } catch (e) {
    return { ids: [] };
  }
}
function saveShownBigEventState(username, state) {
  try { localStorage.setItem(bigEventsShownKey(username), JSON.stringify(state)); } catch (e) { /* ignore */ }
}

async function checkBigEventPopup(username, classCode) {
  if (!username || !classCode) return;
  if (anyModalShowing()) return; // something's already showing
  const cls = await getClass(classCode);
  if (!cls) return;

  // Bad events (job/property/vehicle at risk) take priority — forced
  // modal, must be resolved via pay / forfeit / claim before continuing.
  const pending = (cls.bigEventLog || []).find(e => e.studentUser === username && e.status === "pending");
  if (pending) {
    const user = await getUser(username);
    const coverage = BIG_EVENT_COVERAGE[pending.module];
    const plan = (user.insurance || []).map(id => cls.insurancePlans.find(p => p.id === id)).find(p => p && p.coverage === coverage);
    showBigEventPopup(pending, plan, username, classCode, user);
    return;
  }

  // Good (windfall) events are already paid out the moment they're
  // generated — this just shows a friendly, dismissible heads-up the
  // first time the student sees it, same one-time-shown pattern as the
  // regular weekly events.
  const state = getShownBigEventState(username);
  const shown = new Set(state.ids);
  const unseenGood = (cls.bigEventLog || [])
    .find(e => e.studentUser === username && e.status === "received" && !shown.has(e.id));
  if (!unseenGood) return;

  showGoodBigEventPopup(unseenGood);
  state.ids = state.ids.concat([unseenGood.id]);
  saveShownBigEventState(username, state);
}

function showGoodBigEventPopup(entry) {
  const overlay = document.createElement("div");
  overlay.id = "anwGoodBigEventModal";
  overlay.className = "anw-modal-overlay";

  overlay.innerHTML = `
    <div class="anw-modal-card">
      <h2 style="display:flex;align-items:center;gap:9px;">${icon("star", 24)} Big event: ${entry.name}</h2>
      <p>${entry.description || ""}</p>
      <p class="ticker-up" style="font-weight:900;font-size:1.2em;">+${fmtMoney(entry.cost)}</p>
      <button class="btn gold" style="width:100%;justify-content:center;margin-top:16px;" id="anwGoodBigEventCloseBtn">Nice, got it</button>
    </div>
  `;
  document.body.appendChild(overlay);
  document.getElementById("anwGoodBigEventCloseBtn").addEventListener("click", () => overlay.remove());
  overlay.addEventListener("click", (e) => { if (e.target === overlay) overlay.remove(); });
}

function showBigEventPopup(entry, plan, username, classCode, user) {
  const overlay = document.createElement("div");
  overlay.id = "anwBigEventModal";
  overlay.className = "anw-modal-overlay";

  const assetLabel = { income: "your job", property: "your property", transport: "your vehicle" }[entry.module];
  // Some events are only ever a cost — the def can be set so not paying
  // never takes the associated job/property/vehicle away. Older log
  // entries (created before this option existed) had no such field, so
  // treat that as "at risk", same as before.
  const canForfeit = entry.takesAsset !== false;

  // Teachers can hit this modal too (defensive — resolveBigEvent lets them
  // pay/claim regardless of balance), so don't gate their buttons on funds
  // they don't actually need.
  const isTeacher = user && user.role === "teacher";
  const cash = (user && user.balance) || 0;
  const savings = (user && user.savings) || 0;
  const cashOk = isTeacher || cash >= entry.cost;
  const savingsOk = isTeacher || savings >= entry.cost;

  overlay.innerHTML = `
    <div class="anw-modal-card">
      <h2 style="display:flex;align-items:center;gap:9px;">${icon("star", 24)} Big event: ${entry.name}</h2>
      <p>${entry.description || ""}</p>
      <p><strong>${BIG_EVENT_MODULE_LABEL[entry.module]}</strong> &middot; costs <strong>${fmtMoney(entry.cost)}</strong> to resolve</p>
      <p class="muted-small">${canForfeit ? "You need to choose how to handle this before you can continue." : `This doesn't put ${assetLabel} at risk — you just need to cover the cost, or claim insurance if you have it.`}</p>
      <div style="display:flex;flex-direction:column;gap:10px;margin-top:14px;">
        ${canForfeit ? `<button class="btn coral" id="bigForfeitBtn">Don't pay — lose ${assetLabel}</button>` : ""}
        <button class="btn gold" id="bigPayCashBtn" ${cashOk ? "" : "disabled"}>
          Pay ${fmtMoney(entry.cost)} from cash${cashOk ? "" : ` (only ${fmtMoney(cash)} available)`}
        </button>
        <button class="btn gold" id="bigPaySavingsBtn" ${savingsOk ? "" : "disabled"}>
          Pay ${fmtMoney(entry.cost)} from savings${savingsOk ? "" : ` (only ${fmtMoney(savings)} available)`}
        </button>
        <button class="btn secondary" id="bigClaimBtn" ${plan ? "" : "disabled"}>
          ${plan ? `Claim insurance (${plan.name}) — pay ${fmtMoney(plan.excess)} excess` : "Claim insurance (no matching plan)"}
        </button>
      </div>
      <div id="bigEventMsg"></div>
    </div>
  `;
  document.body.appendChild(overlay);

  // Only buttons that are actually usable get toggled between attempts.
  // Buttons disabled because of a genuine constraint (not enough cash, not
  // enough savings, no matching insurance plan) must STAY disabled after a
  // failed attempt at a different option — previously ALL buttons were
  // blindly re-enabled on any error, which could un-disable e.g. "Claim
  // insurance" for a student with no matching plan.
  const eligibleIds = [];
  if (canForfeit) eligibleIds.push("bigForfeitBtn");
  if (cashOk) eligibleIds.push("bigPayCashBtn");
  if (savingsOk) eligibleIds.push("bigPaySavingsBtn");
  if (plan) eligibleIds.push("bigClaimBtn");
  const setBusy = (busy) => {
    eligibleIds.forEach(id => { document.getElementById(id).disabled = busy; });
  };

  const resolve = async (choice, paySource) => {
    setBusy(true);
    const res = await resolveBigEvent(username, classCode, entry.id, choice, paySource);
    if (res.ok) {
      overlay.remove();
      if (typeof render === "function") render();
    } else {
      document.getElementById("bigEventMsg").innerHTML = `<div class="error-msg">${res.error}</div>`;
      setBusy(false);
    }
  };

  if (canForfeit) document.getElementById("bigForfeitBtn").addEventListener("click", () => resolve("forfeit"));
  document.getElementById("bigPayCashBtn").addEventListener("click", () => resolve("pay", "cash"));
  document.getElementById("bigPaySavingsBtn").addEventListener("click", () => resolve("pay", "savings"));
  document.getElementById("bigClaimBtn").addEventListener("click", () => resolve("claim"));
}
